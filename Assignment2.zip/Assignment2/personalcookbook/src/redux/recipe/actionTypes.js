export const actionTypes = {
  GET_RECIPES: "recipe/getRecipes",
  ADD_RECIPE: "recipe/addRecipe",
  DELETE_RECIPE: "recipe/deleteRecipe",
};
